import streamlit as st

def show_welcome_screen():
    """
    Função simples para popup de boas-vindas
    """
    # Por simplicidade, não mostra popup
    return False

