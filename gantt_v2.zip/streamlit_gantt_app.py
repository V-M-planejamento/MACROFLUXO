import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import numpy as np
import json
import datetime
from datetime import datetime

# --- Bloco de Importação de Dados ---
try:
    from tratamento_dados_reais import processar_cronograma
    from tratamento_macrofluxo import tratar_macrofluxo
    from calculate_business_days import calculate_business_days
except ImportError:
    st.warning("Scripts de processamento não encontrados. O app usará dados de exemplo.")
    processar_cronograma = None
    tratar_macrofluxo = None
    calculate_business_days = None

# --- Definição dos Grupos ---
GRUPOS = {
    "PLANEJAMENTO MACROFLUXO": [
        "PROSPECÇÃO",
        "LEGALIZAÇÃO PARA VENDA",
        "PULMÃO VENDA",
    ],
    "LIMPEZA 'SUPRESSÃO'": [
        "PL.LIMP",
        "LEG.LIMP",
        "ENG. LIMP.",
        "EXECUÇÃO LIMP.",
    ],
    "TERRAPLANAGEM": [
        "PL.TER.",
        "LEG.TER.",
        "ENG. TER.",
        "EXECUÇÃO TER.",
    ],
    "INFRA INCIDENTE (SAA E SES)": [
        "PL.INFRA",
        "LEG.INFRA",
        "ENG. INFRA",
        "EXECUÇÃO INFRA",
        "ENG. PAV",
        "EXECUÇÃO PAV.",
    ],
    "PULMÃO": ["PULMÃO INFRA"],
    "RADIER": ["PL.RADIER", "LEG.RADIER", "PULMÃO RADIER", "RADIER"],
    "DEMANDA MÍNIMA": ["DEMANDA MÍNIMA"],
}

SETOR = {
    "PROSPECÇÃO": ["PROSPECÇÃO"],
    "LEGALIZAÇÃO": ["LEGALIZAÇÃO PARA VENDA", "LEG.LIMP", "LEG.TER.", "LEG.INFRA"],
    "PULMÃO": ["PULMÃO VENDA", "PULMÃO INFRA", "PULMÃO RADIER"],
    "ENGENHARIA": ["PL.LIMP", "ENG.LIMP.", "PL.TER.", "ENG. TER.", "PL.INFRA", "ENG. INFRA", "ENG. PAV"],
    "INFRA": ["EXECUÇÃO LIMP.", "EXECUÇÃO TER.", "EXECUÇÃO INFRA", "EXECUÇÃO PAV.", "PL.RADIER"],
    "PRODUÇÃO": ["RADIER"],
    "NOVOS PRODUTOS": ["LEG.RADIER"],
    "VENDA": ["DEMANDA MÍNIMA"],
}

# --- Mapeamentos e Padronização ---
mapeamento_etapas_usuario = {
    "PROSPECÇÃO": "PROSPEC",
    "LEGALIZAÇÃO PARA VENDA": "LEGVENDA",
    "PULMÃO VENDA": "PULVENDA",
    "PL.LIMP": "PL.LIMP",
    "LEG.LIMP": "LEG.LIMP",
    "ENG. LIMP.": "ENG.LIMP",
    "EXECUÇÃO LIMP.": "EXECLIMP",
    "PL.TER.": "PL.TER",
    "LEG.TER.": "LEG.TER",
    "ENG. TER.": "ENG.TER",
    "EXECUÇÃO TER.": "EXECTER",
    "PL.INFRA": "PL.INFRA",
    "LEG.INFRA": "LEG.INFRA",
    "ENG. INFRA": "ENG.INFRA",
    "EXECUÇÃO INFRA": "EXECINFRA",
    "LEG.PAV": "LEG.PAV",
    "ENG. PAV": "ENG.PAV",
    "EXECUÇÃO PAV.": "EXEC.PAV",
    "PULMÃO INFRA": "PUL.INFRA",
    "PL.RADIER": "PL.RAD",
    "LEG.RADIER": "LEG.RAD",
    "RADIER": "RAD",
    "DEMANDA MÍNIMA": "DEM.MIN",
}

mapeamento_reverso = {v: k for k, v in mapeamento_etapas_usuario.items()}

sigla_para_nome_completo = {
    "PROSPEC": "PROSPECÇÃO",
    "LEGVENDA": "LEGALIZAÇÃO PARA VENDA",
    "PULVENDA": "PULMÃO VENDA",
    "PL.LIMP": "PL.LIMP",
    "LEG.LIMP": "LEG.LIMP",
    "ENG.LIMP": "ENG. LIMP.",
    "EXECLIMP": "EXECUÇÃO LIMP.",
    "PL.TER": "PL.TER.",
    "LEG.TER": "LEG.TER.",
    "ENG.TER": "ENG. TER.",
    "EXECTER": "EXECUÇÃO TER.",
    "PL.INFRA": "PL.INFRA",
    "LEG.INFRA": "LEG.INFRA",
    "ENG.INFRA": "ENG. INFRA",
    "EXECINFRA": "EXECUÇÃO INFRA",
    "LEG.PAV": "LEG.PAV",
    "ENG.PAV": "ENG. PAV",
    "EXEC.PAV": "EXECUÇÃO PAV.",
    "PUL.INFRA": "PULMÃO INFRA",
    "PL.RAD": "PL.RADIER",
    "LEG.RAD": "LEG.RADIER",
    "RAD": "RADIER",
    "DEM.MIN": "DEMANDA MÍNIMA",
}

nome_completo_para_sigla = {v: k for k, v in sigla_para_nome_completo.items()}

# --- Mapa de Setor por Etapa ---
GRUPO_POR_ETAPA = {sigla: grupo for grupo, etapas in GRUPOS.items() for etapa in etapas for sigla in [mapeamento_etapas_usuario.get(etapa, etapa)]}
SETOR_POR_ETAPA = {sigla: setor for setor, etapas in SETOR.items() for etapa in etapas for sigla in [mapeamento_etapas_usuario.get(etapa, etapa)]}

# --- Cores por Setor ---
CORES_POR_SETOR = {
    "PROSPECÇÃO": {"previsto": "#ffdea1", "real": "#6C3F00"}, 
    "LEGALIZAÇÃO": {"previsto": "#ebc7ef", "real": "#63006E"},
    "PULMÃO": {"previsto": "#bdbdbd", "real": "#5f5f5f"},
    "ENGENHARIA": {"previsto": "#ffe1af", "real": "#be5900"},
    "INFRA": {"previsto": "#b9ddfc", "real": "#003C6C"},
    "PRODUÇÃO": {"previsto": "#5E605F", "real": "#121212"},
    "NOVOS PRODUTOS": {"previsto": "#9691FD", "real": "#453ECC"},
    "VENDA": {"previsto": "#c6e7c8", "real": "#014606"}
}

# --- Configuração da página ---
st.set_page_config(
    page_title="Gráfico de Gantt Integrado",
    page_icon="📊",
    layout="wide"
)

# --- Funções Utilitárias ---
def abreviar_nome(nome):
    if pd.isna(nome):
        return nome
    nome = nome.replace("CONDOMINIO ", "")
    palavras = nome.split()
    if len(palavras) > 3:
        nome = " ".join(palavras[:3])
    return nome

def converter_porcentagem(valor):
    if pd.isna(valor) or valor == "":
        return 0.0
    if isinstance(valor, str):
        valor = "".join(c for c in valor if c.isdigit() or c in [".", ","]).replace(",", ".").strip()
        if not valor:
            return 0.0
    try:
        return float(valor) * 100 if float(valor) <= 1 else float(valor)
    except (ValueError, TypeError):
        return 0.0

def padronizar_etapa(etapa_str):
    if pd.isna(etapa_str):
        return "UNKNOWN"
    etapa_limpa = str(etapa_str).strip().upper()
    if etapa_limpa in sigla_para_nome_completo:
        return etapa_limpa
    if etapa_limpa in mapeamento_etapas_usuario:
        return mapeamento_etapas_usuario[etapa_limpa]
    return "UNKNOWN"

def obter_data_meta_assinatura(df_original, empreendimento):
    df_meta = df_original[
        (df_original["Empreendimento"] == empreendimento) & 
        (df_original["Etapa"] == "DEM.MIN")
    ]
    
    if df_meta.empty:
        return None
    
    if pd.notna(df_meta["Termino_Prevista"].iloc[0]):
        return df_meta["Termino_Prevista"].iloc[0]
    elif pd.notna(df_meta["Inicio_Prevista"].iloc[0]):
        return df_meta["Inicio_Prevista"].iloc[0]
    elif pd.notna(df_meta["Termino_Real"].iloc[0]):
        return df_meta["Termino_Real"].iloc[0]
    elif pd.notna(df_meta["Inicio_Real"].iloc[0]):
        return df_meta["Inicio_Real"].iloc[0]
    else:
        return None
# --- Função de Carregamento de Dados Corrigida ---
@st.cache_data
def load_data():
    df_real = pd.DataFrame()
    df_previsto = pd.DataFrame()
    
    if processar_cronograma:
        try:
            df_real_resultado = processar_cronograma("GRÁFICO MACROFLUXO.xlsx")
            if df_real_resultado is not None and not df_real_resultado.empty:
                df_real = df_real_resultado.copy()
                df_real["Etapa"] = df_real["Etapa"].apply(padronizar_etapa)
                df_real = df_real.rename(columns={"EMP": "Empreendimento", "%_Concluido": "% concluído"})
                if "% concluído" in df_real.columns:
                    df_real["% concluído"] = df_real["% concluído"].apply(converter_porcentagem)
                df_real_pivot = df_real.pivot_table(
                    index=["Empreendimento", "Etapa", "% concluído"],
                    columns="Inicio_Fim", values="Valor", aggfunc="first"
                ).reset_index()
                df_real_pivot.columns.name = None
                df_real_pivot = df_real_pivot.rename(columns={"INICIO": "Inicio_Real", "TERMINO": "Termino_Real"})
                df_real = df_real_pivot
        except Exception as e:
            st.warning(f"Erro ao carregar dados reais: {e}")

    if tratar_macrofluxo:
        try:
            df_previsto_resultado = tratar_macrofluxo()
            if df_previsto_resultado is not None and not df_previsto_resultado.empty:
                df_previsto = df_previsto_resultado.copy()
                df_previsto["Etapa"] = df_previsto["Etapa"].apply(padronizar_etapa)
                df_previsto = df_previsto.rename(columns={"EMP": "Empreendimento", "UGB": "UGB"})
                df_previsto_pivot = df_previsto.pivot_table(
                    index=["UGB", "Empreendimento", "Etapa"],
                    columns="Inicio_Fim", values="Valor", aggfunc="first"
                ).reset_index()
                df_previsto_pivot.columns.name = None
                df_previsto_pivot = df_previsto_pivot.rename(columns={"INICIO": "Inicio_Prevista", "TERMINO": "Termino_Prevista"})
                df_previsto = df_previsto_pivot
        except Exception as e:
            st.warning(f"Erro ao carregar dados previstos: {e}")

    if df_real.empty and df_previsto.empty:
        st.warning("Nenhuma fonte de dados carregada. Usando dados de exemplo.")
        return criar_dados_exemplo()
    def criar_dados_exemplo():
    # ... (Sua função de dados de exemplo)
        return pd.DataFrame()

    if not df_real.empty and not df_previsto.empty:
        df_merged = pd.merge(df_previsto, df_real, on=["Empreendimento", "Etapa"], how="outer")
    else:
        df_merged = df_previsto if not df_previsto.empty else df_real

    for col in ["UGB", "Inicio_Prevista", "Termino_Prevista", "Inicio_Real", "Termino_Real", "% concluído"]:
        if col not in df_merged.columns:
            df_merged[col] = pd.NaT if "data" in col.lower() else ("UGB1" if col == "UGB" else 0.0)

    df_merged["% concluído"] = df_merged["% concluído"].fillna(0)
    df_merged.dropna(subset=["Empreendimento", "Etapa"], inplace=True)
    df_merged["GRUPO"] = df_merged["Etapa"].map(GRUPO_POR_ETAPA).fillna("Não especificado")
    df_merged["SETOR"] = df_merged["Etapa"].map(SETOR_POR_ETAPA).fillna("Não especificado")
    return df_merged

def processar_dados_para_gantt(df):
    """Processa os dados do DataFrame para o formato JSON necessário para o Gantt"""
    if df.empty:
        return []
    
    # Padronizar etapas
    df['Etapa'] = df['Etapa'].apply(padronizar_etapa)
    
    # Converter porcentagens
    if '% concluído' in df.columns:
        df['% concluído'] = df['% concluído'].apply(converter_porcentagem)
    else:
        df['% concluído'] = 0.0
    
    # Converter datas
    for col in ['Inicio_Prevista', 'Termino_Prevista', 'Inicio_Real', 'Termino_Real']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')
    
    # Abreviar nomes dos empreendimentos
    if 'Empreendimento' in df.columns:
        df['Empreendimento'] = df['Empreendimento'].apply(abreviar_nome)
    
    # Agrupar dados por empreendimento e etapa
    dados_agrupados = df.groupby(['Empreendimento', 'Etapa']).agg({
        'Inicio_Prevista': 'min',
        'Termino_Prevista': 'max',
        'Inicio_Real': 'min',
        'Termino_Real': 'max',
        '% concluído': 'max'
    }).reset_index()
    
    # Converter para formato JSON
    gantt_data = []
    for idx, row in dados_agrupados.iterrows():
        item = {
            "id": f"task_{idx}",
            "empreendimento": row['Empreendimento'],
            "etapa": row['Etapa'],
            "name": sigla_para_nome_completo.get(row['Etapa'], row['Etapa']),
            "percent_concluido": row['% concluído'],
            "setor": SETOR_POR_ETAPA.get(row['Etapa'], "OUTROS"),
            "inicio_previsto": f"/Date({int(row['Inicio_Prevista'].timestamp() * 1000)})/" if pd.notna(row['Inicio_Prevista']) else None,
            "termino_previsto": f"/Date({int(row['Termino_Prevista'].timestamp() * 1000)})/" if pd.notna(row['Termino_Prevista']) else None,
            "inicio_real": f"/Date({int(row['Inicio_Real'].timestamp() * 1000)})/" if pd.notna(row['Inicio_Real']) else None,
            "termino_real": f"/Date({int(row['Termino_Real'].timestamp() * 1000)})/" if pd.notna(row['Termino_Real']) else None,
        }
        gantt_data.append(item)
    
    return gantt_data

# --- Interface do usuário ---
st.title("📊 Gráfico de Gantt Integrado")
st.markdown("---")

# Sidebar para controles
with st.sidebar:
    st.header("Configurações")
    
    # Opção para carregar dados
    usar_dados_reais = st.checkbox("Usar dados reais (se disponível)", value=False)
    
    # Filtros
    st.subheader("Filtros")
    filtrar_por_etapa = st.selectbox(
        "Filtrar por etapa específica:",
        options=["Todas"] + list(sigla_para_nome_completo.values()),
        index=0
    )
    
    mostrar_apenas_nao_concluidas = st.checkbox("Mostrar apenas etapas não concluídas", value=False)

# Carregar dados
if usar_dados_reais and processar_cronograma is not None:
    try:
        df_dados = processar_cronograma()
        st.success("Dados reais carregados com sucesso!")
    except Exception as e:
        st.error(f"Erro ao carregar dados reais: {e}")
        df_dados = pd.DataFrame()
else:
    # Dados de exemplo
    df_dados = pd.DataFrame({
        'Empreendimento': ['CONDOMINIO EXEMPLO A', 'CONDOMINIO EXEMPLO A', 'CONDOMINIO EXEMPLO A', 
                          'CONDOMINIO EXEMPLO B', 'CONDOMINIO EXEMPLO B', 'CONDOMINIO EXEMPLO B'],
        'Etapa': ['PROSPECÇÃO', 'LEGALIZAÇÃO PARA VENDA', 'PULMÃO VENDA', 
                 'PROSPECÇÃO', 'LEGALIZAÇÃO PARA VENDA', 'PULMÃO VENDA'],
        'Inicio_Prevista': ['2024-09-01', '2024-09-05', '2024-09-12', 
                           '2024-09-01', '2024-09-05', '2024-09-12'],
        'Termino_Prevista': ['2024-09-10', '2024-09-15', '2024-09-20', 
                            '2024-09-10', '2024-09-15', '2024-09-20'],
        'Inicio_Real': ['2024-09-01', '2024-09-06', '2024-09-13', 
                       '2024-09-01', '2024-09-06', '2024-09-13'],
        'Termino_Real': ['2024-09-08', '2024-09-14', None, 
                        '2024-09-08', '2024-09-14', None],
        '% concluído': [100, 100, 50, 100, 100, 50]
    })

# Aplicar filtros
if not df_dados.empty:
    df_filtrado = df_dados.copy()
    
    # Filtrar por etapa específica
    if filtrar_por_etapa != "Todas":
        etapa_sigla = nome_completo_para_sigla.get(filtrar_por_etapa)
        if etapa_sigla:
            df_filtrado = df_filtrado[df_filtrado['Etapa'].str.upper() == etapa_sigla]
    
    # Filtrar apenas não concluídas
    if mostrar_apenas_nao_concluidas and '% concluído' in df_filtrado.columns:
        df_filtrado['% concluído'] = df_filtrado['% concluído'].apply(converter_porcentagem)
        df_filtrado = df_filtrado[df_filtrado['% concluído'] < 100]
    
    # Processar dados para o Gantt
    gantt_data = processar_dados_para_gantt(df_filtrado)
    
    if gantt_data:
        # Determinar se deve gerar gráficos por empreendimento ou comparativo
        empreendimentos_unicos = list(set([item['empreendimento'] for item in gantt_data]))
        etapas_unicas = list(set([item['etapa'] for item in gantt_data]))
        
        # Calcular datas de meta para cada empreendimento
        datas_meta = {}
        for emp in empreendimentos_unicos:
            data_meta = obter_data_meta_assinatura(df_dados, emp)
            if data_meta:
                datas_meta[emp] = int(data_meta.timestamp() * 1000)
        
        gantt_data_json = json.dumps(gantt_data)
        datas_meta_json = json.dumps(datas_meta)
        cores_por_setor_json = json.dumps(CORES_POR_SETOR)
        
        # Determinar modo de exibição
        if len(empreendimentos_unicos) > 1 and len(etapas_unicas) == 1:
            modo_exibicao = "comparativo"
            st.subheader(f"Comparativo da Etapa: {filtrar_por_etapa}")
        elif len(empreendimentos_unicos) > 1:
            modo_exibicao = "multiplo"
            st.subheader("Gráficos por Empreendimento")
        else:
            modo_exibicao = "individual"
            st.subheader(f"Empreendimento: {empreendimentos_unicos[0]}")
        
        # CSS atualizado
        gantt_css = """
        /* Estilos atualizados para formatação similar ao matplotlib */
        .gantt-container { 
            width: 100%; 
            margin: 20px auto; 
            border: 1px solid #ddd; 
            background-color: #fff; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            font-size: 12px; 
            border-radius: 4px; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
        }

        .fn-gantt { 
            position: relative; 
            overflow: hidden; 
            border: 1px solid #ddd; 
            background-color: #fff; 
            border-radius: 4px; 
            margin-bottom: 30px;
        }

        .fn-gantt-data { 
            position: relative; 
            overflow: hidden; 
            min-height: 400px; 
        }

        .fn-gantt-leftpanel { 
            position: absolute; 
            left: 0; 
            top: 0; 
            width: 280px; 
            background-color: #f8f9fa; 
            border-right: 2px solid #dee2e6; 
            overflow: hidden; 
            z-index: 2; 
        }

        .fn-gantt-rightpanel { 
            margin-left: 280px; 
            position: relative; 
            overflow-x: auto; 
            overflow-y: hidden; 
            background-color: #fff; 
        }

        .fn-gantt-rows ul { 
            list-style: none; 
            margin: 0; 
            padding: 0; 
        }

        .fn-gantt-rows li { 
            border-bottom: 1px solid #d1d5db; 
            padding: 8px; 
            height: 90px; 
            line-height: 1.2; 
            background-color: #f8f9fa; 
            transition: background-color 0.2s ease;
            position: relative;
        }

        .fn-gantt-rows li:nth-child(even) { 
            background-color: #ffffff; 
        }

        .fn-gantt-rows li:nth-child(odd) { 
            background-color: #f1f3f5; 
        }

        .fn-gantt-rows li:hover { 
            background-color: #e9ecef; 
        }

        /* Estilo do nome da etapa */
        .fn-gantt-label strong { 
            font-weight: bold; 
            display: block; 
            color: #2c3e50; 
            font-size: 12px;
            margin-bottom: 4px;
        }

        /* Container para as informações de data */
        .fn-gantt-dates {
            font-family: 'Courier New', monospace;
            font-size: 10px;
            color: #2c3e50;
            line-height: 1.3;
        }

        .fn-gantt-dates .date-line {
            margin-bottom: 2px;
        }

        /* Container para porcentagem */
        .fn-gantt-percent {
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            width: 50px;
            height: 30px;
            border: 1px solid #d1d5db;
            border-radius: 3px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
            background-color: white;
        }

        /* Cores para diferentes estados da porcentagem */
        .percent-completed { 
            background-color: #e6f5eb !important; 
            color: #2EAF5B !important; 
        }

        .percent-delayed { 
            background-color: #fae6e6 !important; 
            color: #C30202 !important; 
        }

        .percent-warning { 
            background-color: #faf3d9 !important; 
            color: #A38408 !important; 
        }

        /* Container para variação */
        .fn-gantt-variation {
            position: absolute;
            right: 8px;
            top: 65%;
            font-size: 8px;
            font-weight: bold;
            text-align: center;
            width: 50px;
        }

        .variation-green { color: #0b803c; }
        .variation-red { color: #89281d; }
        .variation-gray { color: #666666; }

        /* Estilos das barras do Gantt */
        .fn-gantt-bars ul { 
            list-style: none; 
            margin: 0; 
            padding: 0; 
            position: relative; 
            background: repeating-linear-gradient( 
                90deg, 
                transparent, 
                transparent 29px, 
                #f1f3f4 29px, 
                #f1f3f4 30px 
            ); 
        }

        .fn-gantt-bars li { 
            height: 90px; 
            border-bottom: 1px solid #d1d5db; 
            position: relative; 
        }

        .fn-gantt-bar { 
            position: absolute; 
            height: 22px; 
            border-radius: 6px; 
            cursor: pointer; 
            z-index: 10; 
            transition: all 0.3s ease; 
            box-shadow: 0 1px 2px rgba(0,0,0,0.1); 
            border: 1px solid rgba(0,0,0,0.2); 
        }

        .fn-gantt-bar:hover { 
            transform: translateY(-1px); 
            box-shadow: 0 2px 4px rgba(0,0,0,0.2); 
        }

        .fn-gantt-barlabel { 
            color: #fff; 
            font-size: 10px; 
            font-weight: bold; 
            padding: 5px 8px; 
            white-space: nowrap; 
            overflow: hidden; 
            text-overflow: ellipsis; 
            line-height: 12px; 
            text-shadow: 0 1px 1px rgba(0,0,0,0.2); 
        }

        /* Timeline */
        .fn-gantt-timeline { 
            background-color: #f8f9fa; 
            border-bottom: 2px solid #dee2e6; 
            height: 40px; 
            position: relative; 
            overflow: hidden; 
        }

        .fn-gantt-timeline-header { 
            display: flex; 
            height: 100%; 
            align-items: center; 
            font-size: 11px; 
            font-weight: bold; 
            color: #495057; 
        }

        .timeline-date { 
            flex: 1; 
            text-align: center; 
            border-right: 1px solid #dee2e6; 
            padding: 0 5px; 
        }

        /* Linha de hoje */
        .linha-hoje {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: red;
            z-index: 15;
        }

        /* Linha de meta */
        .linha-meta {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: #8e44ad;
            z-index: 15;
        }

        /* Botões de controle */
        .options { 
            margin: 20px 0; 
            text-align: center; 
            padding: 15px; 
            background-color: #f8f9fa; 
            border-radius: 4px; 
            border: 1px solid #dee2e6; 
        }

        .options ul { 
            list-style: none; 
            margin: 0; 
            padding: 0; 
            display: flex; 
            flex-wrap: wrap; 
            justify-content: center; 
            gap: 8px; 
        }

        .options button { 
            padding: 8px 16px; 
            background-color: #007bff; 
            color: white; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
            font-size: 12px; 
            font-weight: 500; 
            transition: all 0.2s ease; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
        }

        .options button:hover { 
            background-color: #0056b3; 
        }

        .empreendimento-titulo {
            background-color: #2c3e50;
            color: white;
            padding: 10px;
            margin: 20px 0 10px 0;
            border-radius: 4px;
            font-weight: bold;
            text-align: center;
        }
        """

        # HTML com JavaScript integrado
        html_code = f"""
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="utf-8">
            <title>Gráfico de Gantt Integrado</title>
            <style>
                {gantt_css}
            </style>
        </head>
        <body>
            <div class="gantt-container">
                <div id="gantt-charts"></div>
            </div>
            
            <div class="options">
                <ul>
                    <li><button class="setToday">📅 Hoje</button></li>
                    <li><button class="zoomOut">🔍➖ Zoom Out</button></li>
                    <li><button class="zoomIn">🔍➕ Zoom In</button></li>
                    <li><button class="prevDay">⬅️ Dia Anterior</button></li>
                    <li><button class="nextDay">➡️ Próx. Dia</button></li>
                </ul>
            </div>

            <script src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
            <script>
            (function($) {{
                "use strict";
                
                var ganttData = {gantt_data_json};
                var datasMetaGlobal = {datas_meta_json};
                var coresPorSetor = {cores_por_setor_json};
                var modoExibicao = "{modo_exibicao}";
                
                function parseMsDate(msDateString) {{
                    if (!msDateString) return null;
                    const match = msDateString.match(/\/Date\((\d+)\)\//);
                    if (match && match[1]) {{
                        return new Date(parseInt(match[1]));
                    }}
                    return null;
                }}

                function calcularDiasUteis(dataInicio, dataFim) {{
                    if (!dataInicio || !dataFim) return 0;
                    var dias = 0;
                    var atual = new Date(dataInicio);
                    while (atual <= dataFim) {{
                        var diaSemana = atual.getDay();
                        if (diaSemana !== 0 && diaSemana !== 6) {{
                            dias++;
                        }}
                        atual.setDate(atual.getDate() + 1);
                    }}
                    return dias;
                }}

                function calcularVariacaoTermino(terminoReal, terminoPrevisto) {{
                    if (!terminoPrevisto) return {{ texto: 'V: -', classeCSS: 'variation-gray' }};
                    if (!terminoReal) return {{ texto: 'V: -', classeCSS: 'variation-gray' }};
                    
                    var diff = Math.ceil((terminoReal - terminoPrevisto) / (1000 * 60 * 60 * 24));
                    if (diff < 0) return {{ texto: 'V: ' + diff + 'd', classeCSS: 'variation-green' }};
                    if (diff > 0) return {{ texto: 'V: +' + diff + 'd', classeCSS: 'variation-red' }};
                    return {{ texto: 'V: 0d', classeCSS: 'variation-gray' }};
                }}

                function formatDate(date) {{
                    if (!date) return 'N/D';
                    var d = date.getDate(), m = date.getMonth() + 1, y = date.getFullYear();
                    return (d < 10 ? '0' : '') + d + '/' + (m < 10 ? '0' : '') + m + '/' + (y % 100);
                }}

                function criarGantt(containerId, data, titulo, dataMeta) {{
                    var $container = $('#' + containerId);
                    $container.empty();
                    
                    if (titulo) {{
                        $container.append('<div class="empreendimento-titulo">' + titulo + '</div>');
                    }}
                    
                    var $gantt = $('<div class="fn-gantt"></div>');
                    var $dataPanel = $('<div class="fn-gantt-data"></div>');
                    var $leftPanel = $('<div class="fn-gantt-leftpanel"><div class="fn-gantt-rows"><ul></ul></div></div>');
                    var $rightPanel = $('<div class="fn-gantt-rightpanel"><div class="fn-gantt-timeline"></div><div class="fn-gantt-bars"><ul></ul></div></div>');
                    
                    $dataPanel.append($leftPanel).append($rightPanel);
                    $gantt.append($dataPanel);
                    $container.append($gantt);
                    
                    // Encontrar limites de data
                    var allDates = [];
                    var hoje = new Date();
                    
                    for (var i = 0; i < data.length; i++) {{
                        allDates.push(parseMsDate(data[i].inicio_previsto));
                        allDates.push(parseMsDate(data[i].termino_previsto));
                        allDates.push(parseMsDate(data[i].inicio_real));
                        allDates.push(parseMsDate(data[i].termino_real));
                    }}
                    
                    if (dataMeta) {{
                        allDates.push(new Date(dataMeta));
                    }}
                    
                    var validDates = allDates.filter(Boolean);
                    var minDate, maxDate;
                    
                    if (validDates.length === 0) {{
                        minDate = new Date();
                        maxDate = new Date();
                    }} else {{
                        minDate = new Date(Math.min.apply(null, validDates));
                        maxDate = new Date(Math.max.apply(null, validDates));
                    }}
                    
                    // Ajustar intervalo
                    minDate.setDate(minDate.getDate() - 5);
                    if (dataMeta) {{
                        var dataMetaObj = new Date(dataMeta);
                        dataMetaObj.setDate(dataMetaObj.getDate() + 180); // 6 meses após meta
                        maxDate = new Date(Math.max(maxDate, dataMetaObj));
                    }} else {{
                        maxDate.setDate(maxDate.getDate() + 30);
                    }}
                    
                    var viewStart = new Date(minDate);
                    var viewEnd = new Date(maxDate);
                    
                    function renderGantt() {{
                        $leftPanel.find('ul').empty();
                        $rightPanel.find(".fn-gantt-bars ul").empty();
                        $rightPanel.find(".fn-gantt-timeline").empty();
                        
                        var dayWidth = 40;
                        var $timeline = $('<div class="fn-gantt-timeline-header"></div>');
                        
                        for (var d = new Date(viewStart); d <= viewEnd; d.setDate(d.getDate() + 1)) {{
                            var dateStr = (d.getDate() < 10 ? '0' : '') + d.getDate() + '/' + ((d.getMonth() + 1) < 10 ? '0' : '') + (d.getMonth() + 1);
                            $timeline.append('<div class="timeline-date" style="width: ' + dayWidth + 'px;">' + dateStr + '</div>');
                        }}
                        $rightPanel.find(".fn-gantt-timeline").append($timeline);
                        
                        for (var i = 0; i < data.length; i++) {{
                            var item = data[i];
                            var inicioPrevisto = parseMsDate(item.inicio_previsto);
                            var terminoPrevisto = parseMsDate(item.termino_previsto);
                            var inicioReal = parseMsDate(item.inicio_real);
                            var terminoReal = parseMsDate(item.termino_real);
                            
                            // Cálculo dos dias úteis
                            var diasUteisPrev = calcularDiasUteis(inicioPrevisto, terminoPrevisto);
                            var diasUteisReal = calcularDiasUteis(inicioReal, terminoReal || hoje);
                            
                            // Formatação das datas
                            var textoPrev = 'Prev: ' + formatDate(inicioPrevisto) + ' - ' + formatDate(terminoPrevisto) + ' (' + diasUteisPrev + 'd)';
                            var textoReal = 'Real: ' + formatDate(inicioReal) + ' - ' + formatDate(terminoReal) + ' (' + diasUteisReal + 'd)';
                            
                            // Cálculo da variação
                            var variacao = calcularVariacaoTermino(terminoReal, terminoPrevisto);
                            
                            // Determinação da cor da porcentagem
                            var percentual = item.percent_concluido;
                            var classePercent = '';
                            
                            if (percentual == 100) {{
                                if (terminoReal && terminoPrevisto) {{
                                    if (terminoReal <= terminoPrevisto) {{
                                        classePercent = 'percent-completed';
                                    }} else {{
                                        classePercent = 'percent-delayed';
                                    }}
                                }} else {{
                                    classePercent = 'percent-completed';
                                }}
                            }} else if (percentual < 100) {{
                                if (terminoPrevisto && terminoPrevisto < hoje) {{
                                    classePercent = 'percent-warning';
                                }}
                            }}
                            
                            // Montagem do HTML da linha
                            var $row = $('<li></li>');
                            
                            // Nome da etapa ou empreendimento
                            var nomeExibicao = modoExibicao === 'comparativo' ? item.empreendimento : item.name;
                            var $label = $('<div class="fn-gantt-label"><strong>' + nomeExibicao + '</strong></div>');
                            
                            // Container das datas
                            var $dates = $('<div class="fn-gantt-dates"></div>');
                            $dates.append('<div class="date-line">' + textoPrev + '</div>');
                            $dates.append('<div class="date-line">' + textoReal + '</div>');
                            
                            // Container da porcentagem
                            var percentualTexto = percentual % 1 === 0 ? percentual + '%' : percentual.toFixed(1) + '%';
                            var $percent = $('<div class="fn-gantt-percent ' + classePercent + '">' + percentualTexto + '</div>');
                            
                            // Container da variação
                            var $variation = $('<div class="fn-gantt-variation ' + variacao.classeCSS + '">' + variacao.texto + '</div>');
                            
                            $row.append($label).append($dates).append($percent).append($variation);
                            $leftPanel.find('ul').append($row);
                            
                            var $barRow = $('<li></li>');
                            
                            // Obter cores do setor
                            var setor = item.setor || 'OUTROS';
                            var coresSetor = coresPorSetor[setor] || {{ previsto: '#A8C5DA', real: '#174c66' }};
                            
                            // Barra Previsto
                            if (inicioPrevisto && terminoPrevisto) {{
                                var barStart = (inicioPrevisto - viewStart) / (1000 * 60 * 60 * 24) * dayWidth;
                                var barWidth = (terminoPrevisto - inicioPrevisto) / (1000 * 60 * 60 * 24) * dayWidth;
                                var $bar = $('<div class="fn-gantt-bar" style="top: 18px; left: ' + barStart + 'px; width: ' + barWidth + 'px; background-color: ' + coresSetor.previsto + ';"></div>');
                                $bar.append('<div class="fn-gantt-barlabel">Previsto</div>');
                                $barRow.append($bar);
                            }}
                            
                            // Barra Real
                            if (inicioReal) {{
                                var terminoRealAtual = terminoReal ? terminoReal : hoje;
                                var barStart = (inicioReal - viewStart) / (1000 * 60 * 60 * 24) * dayWidth;
                                var barWidth = (terminoRealAtual - inicioReal) / (1000 * 60 * 60 * 24) * dayWidth;
                                var $bar = $('<div class="fn-gantt-bar" style="top: 45px; left: ' + barStart + 'px; width: ' + barWidth + 'px; background-color: ' + coresSetor.real + ';"></div>');
                                $bar.append('<div class="fn-gantt-barlabel">Real</div>');
                                $barRow.append($bar);
                            }}
                            
                            $rightPanel.find(".fn-gantt-bars ul").append($barRow);
                        }}
                        
                        // Adicionar linha de hoje
                        var hojePos = (hoje - viewStart) / (1000 * 60 * 60 * 24) * dayWidth;
                        if (hojePos >= 0 && hojePos <= (viewEnd - viewStart) / (1000 * 60 * 60 * 24) * dayWidth) {{
                            $rightPanel.find(".fn-gantt-bars").append('<div class="linha-hoje" style="left: ' + hojePos + 'px;"></div>');
                        }}
                        
                        // Adicionar linha de meta
                        if (dataMeta) {{
                            var dataMetaObj = new Date(dataMeta);
                            var metaPos = (dataMetaObj - viewStart) / (1000 * 60 * 60 * 24) * dayWidth;
                            if (metaPos >= 0 && metaPos <= (viewEnd - viewStart) / (1000 * 60 * 60 * 24) * dayWidth) {{
                                $rightPanel.find(".fn-gantt-bars").append('<div class="linha-meta" style="left: ' + metaPos + 'px;"></div>');
                            }}
                        }}
                    }}
                    
                    renderGantt();
                    
                    // Eventos de controle
                    $('.setToday').off('click').on('click', function() {{
                        viewStart = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - 10);
                        viewEnd = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + 10);
                        renderGantt();
                    }});
                    $('.zoomIn').off('click').on('click', function() {{ 
                        viewStart.setDate(viewStart.getDate() + 1); 
                        viewEnd.setDate(viewEnd.getDate() - 1); 
                        renderGantt(); 
                    }});
                    $('.zoomOut').off('click').on('click', function() {{ 
                        viewStart.setDate(viewStart.getDate() - 1); 
                        viewEnd.setDate(viewEnd.getDate() + 1); 
                        renderGantt(); 
                    }});
                    $('.prevDay').off('click').on('click', function() {{ 
                        viewStart.setDate(viewStart.getDate() - 1); 
                        viewEnd.setDate(viewEnd.getDate() - 1); 
                        renderGantt(); 
                    }});
                    $('.nextDay').off('click').on('click', function() {{ 
                        viewStart.setDate(viewStart.getDate() + 1); 
                        viewEnd.setDate(viewEnd.getDate() + 1); 
                        renderGantt(); 
                    }});
                }}

                $(document).ready(function() {{
                    var $chartsContainer = $('#gantt-charts');
                    
                    if (modoExibicao === 'comparativo') {{
                        // Modo comparativo: um gráfico com todos os empreendimentos
                        criarGantt('gantt-charts', ganttData, null, null);
                    }} else if (modoExibicao === 'multiplo') {{
                        // Modo múltiplo: um gráfico para cada empreendimento
                        var empreendimentosUnicos = [...new Set(ganttData.map(item => item.empreendimento))];
                        
                        empreendimentosUnicos.forEach(function(emp, index) {{
                            var dadosEmp = ganttData.filter(item => item.empreendimento === emp);
                            var containerId = 'gantt-emp-' + index;
                            $chartsContainer.append('<div id="' + containerId + '"></div>');
                            
                            var dataMeta = datasMetaGlobal[emp] || null;
                            criarGantt(containerId, dadosEmp, emp, dataMeta);
                        }});
                    }} else {{
                        // Modo individual: um gráfico para o empreendimento único
                        var empreendimento = ganttData[0].empreendimento;
                        var dataMeta = datasMetaGlobal[empreendimento] || null;
                        criarGantt('gantt-charts', ganttData, empreendimento, dataMeta);
                    }}
                }});
            }})(jQuery);
            </script>
        </body>
        </html>
        """

        # Renderizar o componente HTML no Streamlit
        components.html(html_code, height=800, scrolling=True)
    else:
        st.warning("Nenhum dado disponível após aplicar os filtros.")
else:
    st.warning("Nenhum dado disponível para exibir.")
