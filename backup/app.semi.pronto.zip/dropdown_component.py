import streamlit as st
from typing import List, Optional 

def simple_multiselect_dropdown(
    label: str,
    options: List[str],
    key: Optional[str] = None,
    default_selected: Optional[List[str]] = None,
    placeholder: str = "Selecione as opções"
) -> List[str]:
    """
    Filtro multiselect clean usando selectbox customizado
    """
    if key is None:
        raise ValueError("A chave (key) é obrigatória")

    # Estado inicial
    if f"{key}_selected" not in st.session_state:
        st.session_state[f"{key}_selected"] = default_selected or []

    current_selection = st.session_state[f"{key}_selected"]
    
    # Calcula contador
    selected_count = len(current_selection)
    total_options = len(options)
    
    if selected_count == total_options:
        count_text = f"✓ {selected_count}/{total_options}"
    elif selected_count == 0:
        count_text = f"{selected_count}/{total_options}"
    else:
        count_text = f"{selected_count}/{total_options}"

    # Container do filtro
    with st.container():
        col1, col2 = st.columns([3, 1])
        with col1:
            st.write(f"**{label}**")
        with col2:
            st.write(f"<div style='text-align: right; font-size: 12px; color: #6b6b6b;'>{count_text}</div>", unsafe_allow_html=True)

        # Prepara o texto de exibição
        if current_selection:
            selected_display = ", ".join(current_selection)
            if len(selected_display) > 40:
                selected_display = selected_display[:40] + "..."
            display_text = selected_display
        else:
            display_text = placeholder

        # Opções para o dropdown - marca as opções já selecionadas
        dropdown_options = ["Selecione..."]
        
        # Adiciona ações
        if options:
            dropdown_options.extend(["✓ Marcar Todos", "─ Limpar Seleção"])
        
        # Adiciona opções com marcação das selecionadas
        for option in options:
            if option in current_selection:
                dropdown_options.append(f"✓ {option}")
            else:
                dropdown_options.append(option)

        # Selectbox customizado
        selected_option = st.selectbox(
            label="",
            options=dropdown_options,
            index=0,
            key=f"{key}_selectbox",
            label_visibility="collapsed"
        )

        # Lógica de seleção
        if selected_option and selected_option != "Selecione...":
            new_selection = current_selection.copy()
            
            if selected_option == "✓ Marcar Todos":
                new_selection = options.copy()
            elif selected_option == "─ Limpar Seleção":
                new_selection = []
            else:
                # Remove o ✓ se presente para obter o nome real da opção
                option_name = selected_option[2:] if selected_option.startswith("✓ ") else selected_option
                
                # Toggle da opção selecionada
                if option_name in current_selection:
                    new_selection.remove(option_name)
                else:
                    new_selection.append(option_name)

            # Atualiza estado se mudou
            if set(new_selection) != set(current_selection):
                st.session_state[f"{key}_selected"] = new_selection
                st.rerun()

    return st.session_state[f"{key}_selected"]

def main():
    st.sidebar.title("Filtros")

    # PRIMEIRO FILTRO: UGB
    ugb_options = ["UGB 1", "UGB 2", "UGB 3", "UGB 4", "UGB 5", "UGB 6", "UGB 7", "UGB 8", "UGB 9"]
    ugb_selecionadas = simple_multiselect_dropdown(
        label="Filtrar por UGB",
        options=ugb_options,
        key="ugb_filter",
        default_selected=[],
        placeholder="Selecione as UGBs"
    )
    st.sidebar.markdown("---")

    # SEGUNDO FILTRO: SETOR
    setor_options = [f"SETOR {i}" for i in range(1, 9)]
    setor_selecionados = simple_multiselect_dropdown(
        label="Filtrar por SETOR",
        options=setor_options,
        key="setor_filter",
        default_selected=[],
        placeholder="Selecione os Setores"
    )
    st.sidebar.markdown("---")

    # TERCEIRO FILTRO: EMP
    emp_options = [f"EMP {i}" for i in range(1, 24)]
    emp_selecionados = simple_multiselect_dropdown(
        label="Filtrar por EMP",
        options=emp_options,
        key="emp_filter",
        default_selected=emp_options,
        placeholder="Selecione as EMPs"
    )
    st.sidebar.markdown("---") 

    # QUARTO FILTRO: GRUPO
    grupo_options = [f"GRUPO {i}" for i in range(1, 6)]
    grupo_selecionados = simple_multiselect_dropdown(
        label="Filtrar por GRUPO",
        options=grupo_options,
        key="grupo_filter",
        default_selected=grupo_options,
        placeholder="Selecione os Grupos"
    )

    # Área principal
    st.title("Dashboard com Filtros")

    # Mostrar seleções
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("UGBs Selecionadas")
        st.write(ugb_selecionadas if ugb_selecionadas else ["Nenhuma selecionada"])
    
    with col2:
        st.subheader("EMPs Selecionados")
        st.write(f"{len(emp_selecionados)} de {len(emp_options)}")

    col3, col4 = st.columns(2)
    with col3:
        st.subheader("Grupos Selecionados")
        st.write(f"{len(grupo_selecionados)} de {len(grupo_options)}")
    
    with col4:
        st.subheader("Setores Selecionados")
        st.write(setor_selecionados if setor_selecionados else ["Nenhum selecionado"])

if __name__ == "__main__":
    main()