import streamlit.components.v1 as components
import streamlit as st

def create_bridge_component():
    """Cria um componente para comunicação JavaScript-Streamlit"""
    bridge_js = """
    <script>
    // Criar bridge para comunicação com Streamlit
    window.streamlitBridge = function(message) {
        window.parent.postMessage({
            type: 'streamlit',
            data: message
        }, '*');
    };
    
    // Escutar mensagens do Streamlit
    window.addEventListener('message', function(event) {
        if (event.data.type === 'streamlit') {
            // Processar mensagens do Streamlit se necessário
        }
    });
    </script>
    """
    components.html(bridge_js, height=0)

# No seu código principal, após carregar os dados:
create_bridge_component()

# Escutar mensagens do JavaScript
def handle_js_message():
    """Processa mensagens do JavaScript"""
    if 'js_message' in st.session_state:
        message = st.session_state.js_message
        if message.get('type') == 'filtros_atualizados':
            filtros = message.get('filtros', {})
            for chave, valor in filtros.items():
                st.session_state.filtros_sincronizados[chave] = valor
            st.rerun()

# Chamar esta função periodicamente ou após interações
handle_js_message()